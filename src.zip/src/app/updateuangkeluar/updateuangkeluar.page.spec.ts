import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateuangkeluarPage } from './updateuangkeluar.page';

describe('UpdateuangkeluarPage', () => {
  let component: UpdateuangkeluarPage;
  let fixture: ComponentFixture<UpdateuangkeluarPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(UpdateuangkeluarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
