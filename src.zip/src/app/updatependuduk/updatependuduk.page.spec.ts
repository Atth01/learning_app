import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdatependudukPage } from './updatependuduk.page';

describe('UpdatependudukPage', () => {
  let component: UpdatependudukPage;
  let fixture: ComponentFixture<UpdatependudukPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(UpdatependudukPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
